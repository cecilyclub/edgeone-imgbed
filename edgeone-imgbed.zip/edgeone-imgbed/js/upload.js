// ===== Upload Page Logic =====

let uploadPasswordVerified = false;
let currentLinkFormat = 'url';
let uploadResults = [];

// Verify upload password
async function verifyUploadPassword() {
    const password = document.getElementById('uploadPassword').value;
    if (!password) {
        document.getElementById('gateError').textContent = '请输入密码';
        return;
    }

    const btn = document.getElementById('gateBtn');
    btn.disabled = true;
    btn.innerHTML = '<span>验证中...</span>';

    try {
        const res = await apiRequest('/api/verify-password', {
            method: 'POST',
            body: JSON.stringify({ password })
        });
        if (res.success) {
            sessionStorage.setItem('uploadPassword', password);
            uploadPasswordVerified = true;
            document.getElementById('uploadGate').style.display = 'none';
            document.getElementById('uploadMain').style.display = 'block';
            await loadBackends();
        }
    } catch (e) {
        document.getElementById('gateError').textContent = e.message || '密码错误';
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>解锁</span><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
    }
}

// Load backends for select
async function loadBackends() {
    try {
        const res = await apiRequest('/api/backends/list');
        const select = document.getElementById('backendSelect');
        select.innerHTML = '<option value="">自动选择</option>';
        if (res.backends && res.backends.length > 0) {
            res.backends.forEach(b => {
                if (b.enabled) {
                    const opt = document.createElement('option');
                    opt.value = b.id;
                    opt.textContent = b.name;
                    select.appendChild(opt);
                }
            });
        }
    } catch (e) {
        console.log('Load backends failed:', e.message);
    }
}

// Check if password already verified (session)
async function checkSessionPassword() {
    const saved = sessionStorage.getItem('uploadPassword');
    if (saved) {
        try {
            const res = await apiRequest('/api/verify-password', {
                method: 'POST',
                body: JSON.stringify({ password: saved })
            });
            if (res.success) {
                uploadPasswordVerified = true;
                document.getElementById('uploadGate').style.display = 'none';
                document.getElementById('uploadMain').style.display = 'block';
                await loadBackends();
            }
        } catch (e) {
            sessionStorage.removeItem('uploadPassword');
        }
    }
}

// Enter key support
document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('uploadPassword');
    if (passwordInput) {
        passwordInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') verifyUploadPassword();
        });
    }

    // Link format tabs
    document.querySelectorAll('.settings-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentLinkFormat = tab.dataset.format;
            updateAllLinkFormats();
        });
    });

    // Dropzone events
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');

    dropzone.addEventListener('click', () => fileInput.click());

    dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
    });

    dropzone.addEventListener('dragleave', () => {
        dropzone.classList.remove('dragover');
    });

    dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        handleFiles(e.dataTransfer.files);
    });

    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
        fileInput.value = '';
    });

    // Paste upload
    document.addEventListener('paste', (e) => {
        const items = e.clipboardData.items;
        const files = [];
        for (let item of items) {
            if (item.kind === 'file') {
                const file = item.getAsFile();
                if (file) files.push(file);
            }
        }
        if (files.length > 0) {
            handleFiles(files);
        }
    });

    checkSessionPassword();
});

// Handle file upload
async function handleFiles(fileList) {
    if (!uploadPasswordVerified) {
        showToast('请先输入上传密码', 'error');
        return;
    }

    const files = Array.from(fileList);
    const password = sessionStorage.getItem('uploadPassword');
    const backendId = document.getElementById('backendSelect').value;

    for (const file of files) {
        await uploadSingleFile(file, password, backendId);
    }

    if (uploadResults.length > 0) {
        document.getElementById('batchActions').style.display = 'flex';
    }
}

// Upload single file
async function uploadSingleFile(file, password, backendId) {
    const itemId = 'item_' + randomString(8);
    const fileType = getFileType(file.type, file.name);

    // Create result item
    const item = document.createElement('div');
    item.className = 'upload-item';
    item.id = itemId;
    item.innerHTML = `
        <div class="upload-item-icon">${getFileIcon(fileType)}</div>
        <div class="upload-item-info">
            <div class="upload-item-name">${file.name}</div>
            <div class="upload-item-link" id="${itemId}_link">
                <span class="status-upload">上传中... ${formatSize(file.size)}</span>
            </div>
            <div class="upload-progress"><div class="upload-progress-bar" id="${itemId}_bar" style="width:0%"></div></div>
        </div>
        <div class="upload-item-status" id="${itemId}_status"></div>
    `;

    document.getElementById('uploadResults').prepend(item);

    // Update progress (simulated since fetch doesn't support progress easily with FormData)
    const progressBar = document.getElementById(`${itemId}_bar`);
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress = Math.min(progress + 10, 90);
        progressBar.style.width = progress + '%';
    }, 300);

    try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('password', password);
        if (backendId) formData.append('backendId', backendId);

        const xhr = new XMLHttpRequest();
        const result = await new Promise((resolve, reject) => {
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressBar.style.width = percent + '%';
                }
            });
            xhr.addEventListener('load', () => {
                clearInterval(progressInterval);
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(JSON.parse(xhr.responseText));
                } else {
                    try {
                        reject(new Error(JSON.parse(xhr.responseText).error || '上传失败'));
                    } catch (e) {
                        reject(new Error('上传失败'));
                    }
                }
            });
            xhr.addEventListener('error', () => {
                clearInterval(progressInterval);
                reject(new Error('网络错误'));
            });
            xhr.open('POST', '/api/upload');
            const adminToken = localStorage.getItem('adminToken');
            if (adminToken) {
                xhr.setRequestHeader('Authorization', `Bearer ${adminToken}`);
            }
            xhr.send(formData);
        });

        progressBar.style.width = '100%';
        document.getElementById(`${itemId}_status`).innerHTML = '<span class="status-success">&#10003;</span>';

        // Update link display
        const linkEl = document.getElementById(`${itemId}_link`);
        const fileUrl = result.url || (window.location.origin + '/api/file/' + result.id);
        uploadResults.push({ id: itemId, url: fileUrl, name: file.name, data: result });

        updateLinkDisplay(linkEl, fileUrl, file.name);
    } catch (err) {
        clearInterval(progressInterval);
        progressBar.style.width = '100%';
        progressBar.style.background = 'var(--danger)';
        document.getElementById(`${itemId}_status`).innerHTML = '<span class="status-fail">&#10007;</span>';
        document.getElementById(`${itemId}_link`).innerHTML = `<span class="status-fail">${err.message}</span>`;
    }
}

// Update link display based on format
function updateLinkDisplay(el, url, name) {
    const formats = {
        url: url,
        markdown: `![${name}](${url})`,
        html: `<img src="${url}" alt="${name}">`,
        bbcode: `[img]${url}[/img]`
    };
    const link = formats[currentLinkFormat] || url;
    el.innerHTML = `<code onclick="copyToClipboard('${link.replace(/'/g, "\\'")}')">${escapeHtml(link)}</code>`;
}

// Update all link formats
function updateAllLinkFormats() {
    uploadResults.forEach(item => {
        const el = document.getElementById(item.id + '_link');
        if (el) {
            updateLinkDisplay(el, item.url, item.name);
        }
    });
}

// Escape HTML
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Copy all links
function copyAllLinks() {
    const formats = {
        url: (url, name) => url,
        markdown: (url, name) => `![${name}](${url})`,
        html: (url, name) => `<img src="${url}" alt="${name}">`,
        bbcode: (url, name) => `[img]${url}[/img]`
    };
    const links = uploadResults.map(item => formats[currentLinkFormat](item.url, item.name));
    copyToClipboard(links.join('\n'));
}

// Clear results
function clearResults() {
    uploadResults = [];
    document.getElementById('uploadResults').innerHTML = '';
    document.getElementById('batchActions').style.display = 'none';
}
