// ===== Gallery Page Logic =====

let galleryFiles = [];
let galleryCursor = null;
let galleryLoading = false;
let currentFilter = 'all';
let currentView = 'masonry';

// Load gallery files
async function loadGalleryFiles(reset = true) {
    if (galleryLoading) return;
    galleryLoading = true;

    if (reset) {
        galleryFiles = [];
        galleryCursor = null;
        document.getElementById('masonryGrid').innerHTML = '';
        document.getElementById('galleryGrid').innerHTML = '';
    }

    document.getElementById('galleryLoading').style.display = 'block';
    document.getElementById('galleryEmpty').style.display = 'none';
    document.getElementById('loadMoreWrapper').style.display = 'none';

    try {
        const params = new URLSearchParams();
        if (galleryCursor) params.set('cursor', galleryCursor);
        if (currentFilter !== 'all') params.set('type', currentFilter);
        params.set('limit', '30');

        const res = await apiRequest('/api/files?' + params.toString());
        const newFiles = res.files || [];

        galleryFiles = reset ? newFiles : [...galleryFiles, ...newFiles];
        galleryCursor = res.cursor || null;

        renderGallery(newFiles, reset);

        if (galleryFiles.length === 0) {
            document.getElementById('galleryEmpty').style.display = 'block';
        } else if (galleryCursor) {
            document.getElementById('loadMoreWrapper').style.display = 'block';
        }
    } catch (e) {
        showToast('加载失败: ' + e.message, 'error');
    } finally {
        galleryLoading = false;
        document.getElementById('galleryLoading').style.display = 'none';
    }
}

// Render gallery
function renderGallery(files, reset) {
    const container = currentView === 'masonry'
        ? document.getElementById('masonryGrid')
        : document.getElementById('galleryGrid');

    if (reset) container.innerHTML = '';

    files.forEach(file => {
        const fileType = getFileType(file.type, file.name);
        const fileUrl = file.url || ('/api/file/' + file.id);
        const item = document.createElement('div');

        if (currentView === 'masonry') {
            item.className = 'masonry-item';
            item.onclick = () => openLightbox(file);

            if (fileType === 'image') {
                item.innerHTML = `
                    <img src="${fileUrl}" loading="lazy" alt="${escapeAttr(file.name)}" onerror="this.parentElement.style.display='none'">
                    <div class="masonry-item-overlay">
                        <div class="masonry-item-name">${escapeHtml(file.name)}</div>
                        <div class="masonry-item-size">${formatSize(file.size)}</div>
                    </div>
                `;
            } else if (fileType === 'video') {
                item.innerHTML = `
                    <video src="${fileUrl}" preload="metadata" muted></video>
                    <div class="masonry-item-overlay">
                        <div class="masonry-item-name">${escapeHtml(file.name)}</div>
                        <div class="masonry-item-size">${formatSize(file.size)}</div>
                    </div>
                `;
            } else {
                item.innerHTML = `
                    <div style="padding:2rem;text-align:center;color:var(--primary-light)">
                        ${getFileIcon(fileType)}
                        <p style="margin-top:0.5rem;font-size:0.8rem;color:var(--text-secondary)">${escapeHtml(file.name)}</p>
                        <p style="font-size:0.7rem;color:var(--text-muted)">${formatSize(file.size)}</p>
                    </div>
                `;
            }
        } else {
            item.className = 'grid-item';
            item.onclick = () => openLightbox(file);

            if (fileType === 'image') {
                item.innerHTML = `
                    <img src="${fileUrl}" loading="lazy" alt="${escapeAttr(file.name)}" onerror="this.parentElement.style.display='none'">
                    <div class="masonry-item-overlay">
                        <div class="masonry-item-name">${escapeHtml(file.name)}</div>
                    </div>
                `;
            } else if (fileType === 'video') {
                item.innerHTML = `
                    <video src="${fileUrl}" preload="metadata" muted></video>
                    <div class="masonry-item-overlay">
                        <div class="masonry-item-name">${escapeHtml(file.name)}</div>
                    </div>
                `;
            } else {
                item.innerHTML = `
                    <div class="grid-item-file">
                        ${getFileIcon(fileType)}
                        <p>${escapeHtml(file.name)}</p>
                    </div>
                `;
            }
        }

        container.appendChild(item);
    });
}

// Lightbox
function openLightbox(file) {
    const lightbox = document.getElementById('lightbox');
    const fileType = getFileType(file.type, file.name);
    const fileUrl = file.url || ('/api/file/' + file.id);

    const imgEl = document.getElementById('lightboxImage');
    const videoEl = document.getElementById('lightboxVideo');
    const fileEl = document.getElementById('lightboxFile');
    const infoEl = document.getElementById('lightboxInfo');

    imgEl.style.display = 'none';
    videoEl.style.display = 'none';
    fileEl.style.display = 'none';

    if (fileType === 'image') {
        imgEl.src = fileUrl;
        imgEl.alt = file.name;
        imgEl.style.display = 'block';
    } else if (fileType === 'video') {
        videoEl.src = fileUrl;
        videoEl.style.display = 'block';
    } else {
        fileEl.style.display = 'flex';
        document.getElementById('lightboxFileName').textContent = file.name;
        const dlLink = document.getElementById('lightboxDownloadLink');
        dlLink.href = fileUrl;
        dlLink.download = file.name;
    }

    infoEl.innerHTML = `
        <span>${escapeHtml(file.name)} - ${formatSize(file.size)} - ${formatDate(file.uploadTime)}</span>
        <code onclick="copyToClipboard('${fileUrl}')">复制链接</code>
    `;

    lightbox.classList.add('active');
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.classList.remove('active');
    document.getElementById('lightboxImage').src = '';
    document.getElementById('lightboxVideo').src = '';
}

// Load more
function loadMore() {
    loadGalleryFiles(false);
}

// Escape helpers
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

function escapeAttr(str) {
    return (str || '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    // Filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = btn.dataset.filter;
            loadGalleryFiles(true);
        });
    });

    // View toggle
    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentView = btn.dataset.view;

            const masonry = document.getElementById('masonryGrid');
            const grid = document.getElementById('galleryGrid');
            if (currentView === 'masonry') {
                masonry.style.display = 'block';
                grid.style.display = 'none';
            } else {
                masonry.style.display = 'none';
                grid.style.display = 'grid';
            }
            renderGallery(galleryFiles, true);
        });
    });

    // Keyboard support
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeLightbox();
    });

    // Infinite scroll
    window.addEventListener('scroll', () => {
        if (galleryCursor && !galleryLoading) {
            const scrollPos = window.innerHeight + window.scrollY;
            const docHeight = document.body.offsetHeight;
            if (scrollPos >= docHeight - 200) {
                loadGalleryFiles(false);
            }
        }
    });

    // Initial load
    loadGalleryFiles(true);
});
