// ===== Common Utilities =====

// Format file size
function formatSize(bytes) {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Format date
function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleString('zh-CN', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit'
    });
}

// Get file type category
function getFileType(mimeType, fileName) {
    const mt = (mimeType || '').toLowerCase();
    const ext = (fileName || '').split('.').pop().toLowerCase();
    if (mt.startsWith('image/') || ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico', 'avif'].includes(ext)) return 'image';
    if (mt.startsWith('video/') || ['mp4', 'webm', 'mov', 'avi', 'mkv', 'flv'].includes(ext)) return 'video';
    return 'file';
}

// Get file icon SVG
function getFileIcon(fileType) {
    const icons = {
        image: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
        video: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
        file: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>'
    };
    return icons[fileType] || icons.file;
}

// Copy text to clipboard
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('已复制到剪贴板', 'success');
    } catch (e) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('已复制到剪贴板', 'success');
    }
}

// Show toast notification
function showToast(message, type = 'info') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// API request helper
async function apiRequest(url, options = {}) {
    const defaultHeaders = {};
    if (!(options.body instanceof FormData)) {
        defaultHeaders['Content-Type'] = 'application/json';
    }
    const adminToken = localStorage.getItem('adminToken');
    if (adminToken) {
        defaultHeaders['Authorization'] = `Bearer ${adminToken}`;
    }
    const response = await fetch(url, {
        ...options,
        headers: { ...defaultHeaders, ...options.headers }
    });
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || data.message || '请求失败');
        }
        return data;
    }
    if (!response.ok) {
        throw new Error('请求失败');
    }
    return response;
}

// Generate random string
function randomString(length) {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
    }
    return result;
}

// Load site config on page load
async function loadSiteConfig() {
    try {
        const config = await apiRequest('/api/config');
        if (config.siteTitle) {
            document.title = config.siteTitle + (document.title.includes(' - ') ? document.title.split(' - ').pop() : '');
            const titleEl = document.getElementById('siteTitle');
            if (titleEl) titleEl.textContent = config.siteTitle;
        }
        if (config.siteLogo) {
            const logoEl = document.getElementById('siteLogo');
            if (logoEl) logoEl.textContent = config.siteLogo;
        }
        if (config.siteIcon) {
            let iconLink = document.querySelector('link[rel="icon"]');
            if (!iconLink) {
                iconLink = document.createElement('link');
                iconLink.rel = 'icon';
                document.head.appendChild(iconLink);
            }
            iconLink.href = config.siteIcon;
        }
        return config;
    } catch (e) {
        console.log('Config not loaded:', e.message);
        return {};
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadSiteConfig();
});
