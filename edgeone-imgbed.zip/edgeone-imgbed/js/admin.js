// ===== Admin Page Logic =====

let adminFiles = [];
let adminCursor = null;
let adminFilesLoading = false;
let editingBackendId = null;

// Admin login
async function adminLogin() {
    const username = document.getElementById('adminUser').value;
    const password = document.getElementById('adminPass').value;
    const btn = document.getElementById('loginBtn');

    if (!username || !password) {
        document.getElementById('loginError').textContent = '请输入用户名和密码';
        return;
    }

    btn.disabled = true;
    btn.textContent = '登录中...';

    try {
        const res = await apiRequest('/api/admin/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        localStorage.setItem('adminToken', res.token);
        localStorage.setItem('adminUser', username);
        showDashboard();
    } catch (e) {
        document.getElementById('loginError').textContent = e.message || '登录失败';
    } finally {
        btn.disabled = false;
        btn.textContent = '登录';
    }
}

// Show dashboard
async function showDashboard() {
    document.getElementById('adminLogin').style.display = 'none';
    document.getElementById('adminDashboard').style.display = 'block';
    document.getElementById('adminUserDisplay').textContent = localStorage.getItem('adminUser') || 'admin';
    await loadAdminFiles(true);
    await loadAdminBackends();
    await loadAdminSettings();
}

// Admin logout
function adminLogout() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminUser');
    document.getElementById('adminDashboard').style.display = 'none';
    document.getElementById('adminLogin').style.display = 'flex';
    document.getElementById('adminUser').value = '';
    document.getElementById('adminPass').value = '';
}

// Check session
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('adminToken');
    if (token) {
        showDashboard();
    }

    // Tab switching
    document.querySelectorAll('.admin-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
        });
    });

    // Enter key for login
    document.getElementById('adminPass').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') adminLogin();
    });
});

// ===== Files Management =====

async function loadAdminFiles(reset = true) {
    if (adminFilesLoading) return;
    adminFilesLoading = true;

    if (reset) {
        adminFiles = [];
        adminCursor = null;
        document.getElementById('adminFilesGrid').innerHTML = '';
    }

    document.getElementById('adminFilesLoading').style.display = 'block';

    try {
        const params = new URLSearchParams({ limit: '24' });
        if (adminCursor) params.set('cursor', adminCursor);

        const res = await apiRequest('/api/admin/files?' + params.toString());
        adminFiles = reset ? (res.files || []) : [...adminFiles, ...(res.files || [])];
        adminCursor = res.cursor || null;

        renderAdminFiles(res.files || [], reset);

        if (adminCursor) {
            document.getElementById('adminLoadMore').style.display = 'block';
        } else {
            document.getElementById('adminLoadMore').style.display = 'none';
        }
    } catch (e) {
        showToast('加载失败: ' + e.message, 'error');
    } finally {
        adminFilesLoading = false;
        document.getElementById('adminFilesLoading').style.display = 'none';
    }
}

function renderAdminFiles(files, reset) {
    const grid = document.getElementById('adminFilesGrid');
    if (reset) grid.innerHTML = '';

    files.forEach(file => {
        const fileType = getFileType(file.type, file.name);
        const fileUrl = file.url || ('/api/file/' + file.id);
        const card = document.createElement('div');
        card.className = 'admin-file-card';

        let preview = '';
        if (fileType === 'image') {
            preview = `<img src="${fileUrl}" loading="lazy" alt="" onerror="this.style.display='none'">`;
        } else if (fileType === 'video') {
            preview = `<video src="${fileUrl}" preload="metadata" muted></video>`;
        } else {
            preview = `<div class="file-placeholder">${getFileIcon(fileType)}</div>`;
        }

        card.innerHTML = `
            <div class="admin-file-card-preview">${preview}</div>
            <div class="admin-file-card-info">
                <div class="admin-file-card-name">${escapeAdminHtml(file.name)}</div>
                <div class="admin-file-card-meta">
                    <span>${formatSize(file.size)}</span>
                    <span>${formatDate(file.uploadTime)}</span>
                </div>
            </div>
            <div class="admin-file-card-actions">
                <button class="file-action-btn" title="复制链接" onclick="event.stopPropagation();copyToClipboard('${fileUrl}')">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                </button>
                <button class="file-action-btn delete" title="删除" onclick="event.stopPropagation();deleteFile('${file.id}','${file.name}')">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
            </div>
        `;

        card.onclick = () => {
            window.open(fileUrl, '_blank');
        };

        grid.appendChild(card);
    });
}

function loadMoreAdminFiles() {
    loadAdminFiles(false);
}

function searchFiles() {
    const query = document.getElementById('fileSearch').value;
    const typeFilter = document.getElementById('fileTypeFilter').value;
    const grid = document.getElementById('adminFilesGrid');

    if (!query && typeFilter === 'all') {
        renderAdminFiles(adminFiles, true);
        return;
    }

    let filtered = adminFiles;
    if (query) {
        filtered = filtered.filter(f => f.name.toLowerCase().includes(query.toLowerCase()));
    }
    if (typeFilter !== 'all') {
        filtered = filtered.filter(f => getFileType(f.type, f.name) === typeFilter);
    }

    renderAdminFiles(filtered, true);
}

async function deleteFile(fileId, fileName) {
    if (!confirm(`确定删除 "${fileName}" 吗？此操作不可撤销。`)) return;

    try {
        await apiRequest('/api/admin/delete', {
            method: 'POST',
            body: JSON.stringify({ id: fileId })
        });
        showToast('删除成功', 'success');
        loadAdminFiles(true);
    } catch (e) {
        showToast('删除失败: ' + e.message, 'error');
    }
}

// ===== Backend Management =====

async function loadAdminBackends() {
    try {
        const res = await apiRequest('/api/admin/backends');
        renderBackends(res.backends || []);
        updateDefaultBackendSelect(res.backends || []);
    } catch (e) {
        showToast('加载后端失败: ' + e.message, 'error');
    }
}

function renderBackends(backends) {
    const list = document.getElementById('backendsList');
    list.innerHTML = '';

    if (backends.length === 0) {
        list.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--text-muted)">暂无存储后端，请点击"添加后端"</div>';
        return;
    }

    backends.forEach(b => {
        const card = document.createElement('div');
        card.className = 'backend-card';
        card.innerHTML = `
            <div class="backend-card-info">
                <div class="backend-card-name">
                    ${escapeAdminHtml(b.name)}
                    <span class="backend-badge ${b.enabled ? 'enabled' : 'disabled'}">${b.enabled ? '启用' : '停用'}</span>
                </div>
                <div class="backend-card-detail">
                    <span>Chat ID: ${escapeAdminHtml(String(b.chatId))}</span>
                    <span>Token: ${escapeAdminHtml(b.botToken.substring(0, 12))}...</span>
                    ${b.proxyUrl ? `<span>代理: ${escapeAdminHtml(b.proxyUrl)}</span>` : ''}
                </div>
            </div>
            <div class="backend-card-actions">
                <button class="btn-secondary" onclick="editBackend('${b.id}')">编辑</button>
                <button class="btn-secondary" style="color:var(--danger)" onclick="deleteBackend('${b.id}','${escapeAdminHtml(b.name)}')">删除</button>
            </div>
        `;
        list.appendChild(card);
    });
}

function updateDefaultBackendSelect(backends) {
    const select = document.getElementById('settingDefaultBackend');
    const uploadSelect = document.getElementById('backendSelect');
    [select, uploadSelect].forEach(sel => {
        if (!sel) return;
        sel.innerHTML = '<option value="">自动选择</option>';
        backends.forEach(b => {
            if (b.enabled) {
                const opt = document.createElement('option');
                opt.value = b.id;
                opt.textContent = b.name;
                sel.appendChild(opt);
            }
        });
    });
}

function showAddBackendForm() {
    editingBackendId = null;
    document.getElementById('backendFormTitle').textContent = '添加 Telegram Bot 后端';
    document.getElementById('backendForm').style.display = 'block';
    document.getElementById('backendName').value = '';
    document.getElementById('botToken').value = '';
    document.getElementById('chatId').value = '';
    document.getElementById('proxyUrl').value = '';
    document.getElementById('backendEnabled').checked = true;
}

function hideBackendForm() {
    document.getElementById('backendForm').style.display = 'none';
    editingBackendId = null;
}

async function saveBackend() {
    const name = document.getElementById('backendName').value.trim();
    const botToken = document.getElementById('botToken').value.trim();
    const chatId = document.getElementById('chatId').value.trim();
    const proxyUrl = document.getElementById('proxyUrl').value.trim();
    const enabled = document.getElementById('backendEnabled').checked;

    if (!name || !botToken || !chatId) {
        showToast('请填写名称、Bot Token 和 Chat ID', 'error');
        return;
    }

    const btn = document.getElementById('saveBackendBtn');
    btn.disabled = true;
    btn.textContent = '保存中...';

    try {
        const body = { name, botToken, chatId, enabled };
        if (proxyUrl) body.proxyUrl = proxyUrl;

        if (editingBackendId) {
            await apiRequest('/api/admin/backends', {
                method: 'PUT',
                body: JSON.stringify({ id: editingBackendId, ...body })
            });
            showToast('更新成功', 'success');
        } else {
            await apiRequest('/api/admin/backends', {
                method: 'POST',
                body: JSON.stringify(body)
            });
            showToast('添加成功', 'success');
        }

        hideBackendForm();
        await loadAdminBackends();
    } catch (e) {
        showToast('保存失败: ' + e.message, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = '保存';
    }
}

async function editBackend(id) {
    try {
        const res = await apiRequest('/api/admin/backends');
        const backend = (res.backends || []).find(b => b.id === id);
        if (!backend) return;

        editingBackendId = id;
        document.getElementById('backendFormTitle').textContent = '编辑后端';
        document.getElementById('backendForm').style.display = 'block';
        document.getElementById('backendName').value = backend.name;
        document.getElementById('botToken').value = backend.botToken;
        document.getElementById('chatId').value = backend.chatId;
        document.getElementById('proxyUrl').value = backend.proxyUrl || '';
        document.getElementById('backendEnabled').checked = backend.enabled;
    } catch (e) {
        showToast('加载失败: ' + e.message, 'error');
    }
}

async function deleteBackend(id, name) {
    if (!confirm(`确定删除后端 "${name}" 吗？`)) return;

    try {
        await apiRequest('/api/admin/backends', {
            method: 'DELETE',
            body: JSON.stringify({ id })
        });
        showToast('删除成功', 'success');
        await loadAdminBackends();
    } catch (e) {
        showToast('删除失败: ' + e.message, 'error');
    }
}

// ===== Settings =====

async function loadAdminSettings() {
    try {
        const res = await apiRequest('/api/admin/settings');
        document.getElementById('settingSiteTitle').value = res.siteTitle || '';
        document.getElementById('settingSiteLogo').value = res.siteLogo || '';
        document.getElementById('settingSiteIcon').value = res.siteIcon || '';
        document.getElementById('settingUploadPassword').value = res.uploadPassword || '';
        document.getElementById('settingAdminUser').value = res.adminUsername || 'admin';

        if (res.defaultBackend) {
            const select = document.getElementById('settingDefaultBackend');
            select.value = res.defaultBackend;
        }
    } catch (e) {
        console.log('Load settings failed:', e.message);
    }
}

async function saveSettings() {
    const data = {
        siteTitle: document.getElementById('settingSiteTitle').value.trim(),
        siteLogo: document.getElementById('settingSiteLogo').value.trim(),
        siteIcon: document.getElementById('settingSiteIcon').value.trim(),
        uploadPassword: document.getElementById('settingUploadPassword').value.trim(),
        adminUsername: document.getElementById('settingAdminUser').value.trim() || 'admin',
        defaultBackend: document.getElementById('settingDefaultBackend').value
    };

    const newPass = document.getElementById('settingAdminPass').value.trim();
    if (newPass) {
        data.adminPassword = newPass;
    }

    try {
        await apiRequest('/api/admin/settings', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        showToast('设置已保存', 'success');
        loadSiteConfig();
        if (newPass) {
            adminLogout();
            showToast('密码已修改，请重新登录', 'info');
        }
    } catch (e) {
        showToast('保存失败: ' + e.message, 'error');
    }
}

// Helper
function escapeAdminHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}
