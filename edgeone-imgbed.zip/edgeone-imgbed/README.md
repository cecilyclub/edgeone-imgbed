# EdgeOne Pages 图床

基于 **腾讯 EdgeOne Pages** + **Telegram Bot** 的免费图床/文件床系统，使用 EdgeOne KV 数据库存储元数据。

## 功能特性

- **免费无服务器**：部署在 EdgeOne Pages 边缘节点，无需购买服务器
- **Telegram Bot 存储**：利用 Telegram 的免费无限存储作为文件后端
- **多后端支持**：可在后台管理界面添加多个 Telegram Bot，自动负载均衡和故障切换
- **上传密码验证**：上传页面设置密码，防止滥用
- **后台管理**：管理员用户名/密码登录，管理所有文件和后端配置
- **瀑布流展示**：图库页面支持瀑布流（Masonry）和网格两种布局
- **多种链接格式**：上传后支持 URL、Markdown、HTML、BBCode 四种格式复制
- **拖拽/粘贴上传**：支持拖拽文件和剪贴板粘贴上传
- **全文件类型**：支持图片、视频、文档等各种文件格式

## 快速部署

### 第一步：获取 Telegram Bot Token 和 Chat ID

1. 在 Telegram 中搜索 `@BotFather`，发送 `/newbot`
2. 按提示输入 Bot 名称和用户名，获得 **Bot Token**
3. 创建一个新的频道（Channel），将 Bot 设为频道管理员
4. 在频道中发送一条消息，转发给 `@VersaToolsBot` 获取 **Chat ID**

### 第二步：部署到 EdgeOne Pages

1. Fork 本仓库到你的 GitHub
2. 登录 [EdgeOne Pages 控制台](https://edgeone.cloud.tencent.com/pages)
3. 创建新项目，连接 GitHub 仓库
4. 构建配置：
   - 构建命令：`npm install`（或留空）
   - 输出目录：`/`（根目录）

### 第三步：配置 KV 数据库

1. 在 EdgeOne 控制台进入 **KV 存储** 页面
2. 点击 **立即申请** 开通 KV 账户
3. 创建命名空间，名称如 `img_kv`
4. 回到 Pages 项目详情，点击 **KV 存储** -> **绑定命名空间**
5. 变量名填写：**`IMG_KV**（必须一致）
6. 选择刚创建的命名空间，绑定

### 第四步：重新部署

1. 在项目部署页面，点击最新部署的 `...` -> **重试部署**
2. 部署完成后访问你的域名

### 第五步：配置系统

1. 访问 `https://你的域名/admin.html`
2. 默认用户名：`admin`，密码：`admin123`
3. 进入 **存储后端** -> **添加后端**
4. 填入 Telegram Bot Token 和 Chat ID
5. 进入 **系统设置** 修改上传密码和管理员密码

## 项目结构

```
edgeone-imgbed/
├── functions/                  # Edge Functions (API)
│   └── api/
│       └── [[catchall]].js    # 统一 API 路由处理器
├── css/
│   └── style.css              # 全局样式
├── js/
│   ├── common.js              # 公共工具函数
│   ├── upload.js              # 上传页面逻辑
│   ├── gallery.js             # 图库页面逻辑
│   └── admin.js               # 后台管理逻辑
├── index.html                  # 上传页面
├── gallery.html                # 图库页面（瀑布流）
├── admin.html                  # 后台管理页面
├── package.json
├── .gitignore
└── README.md
```

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/config` | 获取公开配置 |
| POST | `/api/verify-password` | 验证上传密码 |
| POST | `/api/upload` | 上传文件 |
| GET | `/api/files` | 获取文件列表 |
| GET | `/api/file/:id` | 获取/下载文件 |
| GET | `/api/backends/list` | 获取启用的后端列表 |
| POST | `/api/admin/login` | 管理员登录 |
| GET/POST/PUT/DELETE | `/api/admin/backends` | 后端 CRUD |
| GET/POST | `/api/admin/settings` | 设置管理 |
| GET | `/api/admin/files` | 管理端文件列表 |
| POST | `/api/admin/delete` | 删除文件 |

## 上传 API 示例

```bash
curl -X POST https://你的域名/api/upload \
  -F "file=@/path/to/image.jpg" \
  -F "password=你的上传密码" \
  -F "backendId=" # 可选，指定后端
```

## 技术栈

- **前端**：HTML5 + CSS3 + 原生 JavaScript
- **后端**：EdgeOne Pages Edge Functions (Web Workers API)
- **存储**：Telegram Bot API（文件存储）+ EdgeOne KV（元数据存储）
- **部署**：腾讯 EdgeOne Pages

## 限制说明

- Telegram Bot 单文件限制 **20MB**
- EdgeOne KV 单条数据最大 **25MB**（仅存储元数据，不存储文件）
- KV 免费版存储容量 **1GB**（元数据足够存储数万条文件记录）

## License

MIT
