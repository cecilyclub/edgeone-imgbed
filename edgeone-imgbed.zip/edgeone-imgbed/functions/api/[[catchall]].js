/**
 * EdgeOne Pages Edge Function - API Router (Catch-all)
 * 
 * Handles all /api/* routes:
 *   GET  /api/config              - Get public site config
 *   POST /api/verify-password      - Verify upload password
 *   POST /api/upload               - Upload file to Telegram Bot
 *   GET  /api/files                - List files (gallery)
 *   GET  /api/file/:id            - Serve/download file
 *   GET  /api/backends/list        - List enabled backends (for upload select)
 *   POST /api/admin/login          - Admin login
 *   GET  /api/admin/backends       - List all backends (admin)
 *   POST /api/admin/backends       - Add backend
 *   PUT  /api/admin/backends       - Update backend
 *   DELETE /api/admin/backends     - Delete backend
 *   GET  /api/admin/settings       - Get settings (admin)
 *   POST /api/admin/settings       - Update settings (admin)
 *   GET  /api/admin/files          - List all files (admin)
 *   POST /api/admin/delete         - Delete file (admin)
 * 
 * KV Variable Name: IMG_KV (bind in EdgeOne Pages console)
 */

// ============================================================
// KV Helper - Access KV namespace from multiple possible sources
// ============================================================
function getKV(context) {
    // Try env binding
    if (context && context.env) {
        if (context.env.IMG_KV) return context.env.IMG_KV;
        if (context.env.img_kv) return context.env.img_kv;
    }
    // Try global variable (EdgeOne style)
    try {
        if (typeof IMG_KV !== 'undefined') return IMG_KV;
    } catch(e) {}
    try {
        if (typeof img_kv !== 'undefined') return img_kv;
    } catch(e) {}
    return null;
}

// ============================================================
// Settings Helper
// ============================================================
const DEFAULT_SETTINGS = {
    siteTitle: '图床',
    siteLogo: 'Cloud',
    siteIcon: '',
    uploadPassword: '',
    adminUsername: 'admin',
    adminPassword: 'admin123',
    defaultBackend: ''
};

async function getSettings(context) {
    const kv = getKV(context);
    if (!kv) return { ...DEFAULT_SETTINGS };
    try {
        const raw = await kv.get('config_settings', { type: 'json' });
        return raw || { ...DEFAULT_SETTINGS };
    } catch(e) {
        try {
            const raw = await kv.get('config_settings');
            return raw ? JSON.parse(raw) : { ...DEFAULT_SETTINGS };
        } catch(e2) {
            return { ...DEFAULT_SETTINGS };
        }
    }
}

async function saveSettings(context, settings) {
    const kv = getKV(context);
    if (!kv) throw new Error('KV not configured');
    const current = await getSettings(context);
    const merged = { ...current, ...settings };
    await kv.put('config_settings', JSON.stringify(merged));
    return merged;
}

// ============================================================
// Backends Helper
// ============================================================
async function getBackends(context) {
    const kv = getKV(context);
    if (!kv) return [];
    try {
        const raw = await kv.get('config_backends', { type: 'json' });
        return raw || [];
    } catch(e) {
        try {
            const raw = await kv.get('config_backends');
            return raw ? JSON.parse(raw) : [];
        } catch(e2) {
            return [];
        }
    }
}

async function saveBackends(context, backends) {
    const kv = getKV(context);
    if (!kv) throw new Error('KV not configured');
    await kv.put('config_backends', JSON.stringify(backends));
}

// ============================================================
// Auth Helper
// ============================================================
async function verifyAdmin(context) {
    const request = context.request;
    const auth = request.headers.get('Authorization') || '';
    if (!auth.startsWith('Bearer ')) return false;
    const token = auth.slice(7);
    const settings = await getSettings(context);
    const expectedToken = btoa(settings.adminUsername + ':' + (settings.adminPassword || 'admin123'));
    return token === expectedToken;
}

// ============================================================
// Telegram Bot Helper
// ============================================================
async function sendFileToTelegram(file, backend) {
    const formData = new FormData();
    formData.append('chat_id', backend.chatId);
    formData.append('document', file, file.name);

    const baseUrl = backend.proxyUrl
        ? backend.proxyUrl.replace(/\/$/, '')
        : 'https://api.telegram.org';
    const url = `${baseUrl}/bot${backend.botToken}/sendDocument`;

    const response = await fetch(url, {
        method: 'POST',
        body: formData
    });

    const data = await response.json();
    if (!data.ok) {
        throw new Error('Telegram API error: ' + (data.description || 'Unknown error'));
    }

    const doc = data.result.document || data.result.photo?.[0] || data.result.video || data.result.audio;
    return {
        messageId: data.result.message_id,
        fileId: doc.file_id,
        fileUniqueId: doc.file_unique_id,
        fileName: doc.file_name || file.name,
        fileSize: doc.file_size || file.size,
        mimeType: doc.mime_type || file.type
    };
}

async function getTelegramFileUrl(backend, fileId) {
    const baseUrl = backend.proxyUrl
        ? backend.proxyUrl.replace(/\/$/, '')
        : 'https://api.telegram.org';
    const url = `${baseUrl}/bot${backend.botToken}/getFile?file_id=${fileId}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!data.ok) {
        throw new Error('Telegram API error: ' + (data.description || 'Unknown error'));
    }
    const filePath = data.result.file_path;
    return `${baseUrl}/file/bot${backend.botToken}/${filePath}`;
}

async function deleteTelegramMessage(backend, chatId, messageId) {
    const baseUrl = backend.proxyUrl
        ? backend.proxyUrl.replace(/\/$/, '')
        : 'https://api.telegram.org';
    const url = `${baseUrl}/bot${backend.botToken}/deleteMessage`;
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, message_id: messageId })
    });
    const data = await response.json();
    return data.ok;
}

// ============================================================
// File Metadata Helper
// ============================================================
function generateFileId() {
    const ts = Date.now().toString(36);
    const rand = Math.random().toString(36).substring(2, 10);
    return `f_${ts}_${rand}`;
}

async function saveFileMetadata(context, meta) {
    const kv = getKV(context);
    if (!kv) throw new Error('KV not configured');
    const key = 'file_' + meta.id;
    await kv.put(key, JSON.stringify(meta));
}

async function getFileMetadata(context, id) {
    const kv = getKV(context);
    if (!kv) return null;
    try {
        const raw = await kv.get('file_' + id, { type: 'json' });
        return raw;
    } catch(e) {
        try {
            const raw = await kv.get('file_' + id);
            return raw ? JSON.parse(raw) : null;
        } catch(e2) {
            return null;
        }
    }
}

async function deleteFileMetadata(context, id) {
    const kv = getKV(context);
    if (!kv) throw new Error('KV not configured');
    await kv.delete('file_' + id);
}

async function listFileMetadata(context, options = {}) {
    const kv = getKV(context);
    if (!kv) return { files: [], cursor: null };
    
    const { limit = 256, cursor = null, type = null } = options;
    let result;
    let allKeys = [];
    
    do {
        result = await kv.list({
            prefix: 'file_',
            limit: 256,
            cursor: cursor || undefined
        });
        if (result.keys) {
            allKeys = allKeys.concat(result.keys);
        }
    } while (result && !result.complete && allKeys.length < 1000);

    // Fetch all metadata
    const files = [];
    for (const keyObj of allKeys) {
        try {
            let meta;
            try {
                meta = await kv.get(keyObj.key, { type: 'json' });
            } catch(e) {
                const raw = await kv.get(keyObj.key);
                meta = raw ? JSON.parse(raw) : null;
            }
            if (meta) {
                // Apply type filter
                if (type) {
                    const fileType = getFileCategory(meta.type, meta.name);
                    if (fileType !== type) continue;
                }
                files.push(meta);
            }
        } catch(e) {
            // Skip invalid entries
        }
    }

    // Sort by upload time (newest first)
    files.sort((a, b) => new Date(b.uploadTime || 0) - new Date(a.uploadTime || 0));

    // Apply limit
    const limited = files.slice(0, limit);
    
    return {
        files: limited,
        cursor: null, // KV doesn't support true pagination, so return null
        total: files.length
    };
}

function getFileCategory(mimeType, fileName) {
    const mt = (mimeType || '').toLowerCase();
    const ext = (fileName || '').split('.').pop().toLowerCase();
    if (mt.startsWith('image/') || ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico', 'avif'].includes(ext)) return 'image';
    if (mt.startsWith('video/') || ['mp4', 'webm', 'mov', 'avi', 'mkv', 'flv'].includes(ext)) return 'video';
    return 'file';
}

// ============================================================
// Response Helpers
// ============================================================
function jsonResponse(data, status = 200) {
    return new Response(JSON.stringify(data), {
        status,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    });
}

function errorResponse(message, status = 400) {
    return jsonResponse({ error: message }, status);
}

function corsResponse() {
    return new Response(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        }
    });
}

// ============================================================
// Main Router
// ============================================================
export async function onRequest(context) {
    const { request, params, env } = context;
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/api\//, '').replace(/^\/$/, '');

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
        return corsResponse();
    }

    try {
        // ---- Public Routes ----
        
        // GET /api/config
        if (path === 'config' && request.method === 'GET') {
            const settings = await getSettings(context);
            return jsonResponse({
                siteTitle: settings.siteTitle,
                siteLogo: settings.siteLogo,
                siteIcon: settings.siteIcon
            });
        }

        // POST /api/verify-password
        if (path === 'verify-password' && request.method === 'POST') {
            const body = await request.json();
            const settings = await getSettings(context);
            const password = settings.uploadPassword;
            
            // If no password set, allow all
            if (!password) {
                return jsonResponse({ success: true });
            }
            
            if (body.password === password) {
                return jsonResponse({ success: true });
            }
            return errorResponse('密码错误', 401);
        }

        // GET /api/backends/list
        if (path === 'backends/list' && request.method === 'GET') {
            const backends = await getBackends(context);
            const settings = await getSettings(context);
            const enabled = backends.filter(b => b.enabled);
            return jsonResponse({
                backends: enabled.map(b => ({
                    id: b.id,
                    name: b.name,
                    type: b.type || 'telegram'
                })),
                defaultBackend: settings.defaultBackend || ''
            });
        }

        // POST /api/upload
        if (path === 'upload' && request.method === 'POST') {
            return await handleUpload(context);
        }

        // GET /api/files
        if (path === 'files' && request.method === 'GET') {
            const type = url.searchParams.get('type') || null;
            const limit = parseInt(url.searchParams.get('limit') || '50');
            const result = await listFileMetadata(context, { limit, type });
            // Add URL prefix to each file
            result.files = result.files.map(f => ({
                ...f,
                url: `/api/file/${f.id}`
            }));
            return jsonResponse(result);
        }

        // GET /api/file/:id
        if (path.startsWith('file/') && request.method === 'GET') {
            return await handleServeFile(context, path.replace('file/', ''));
        }

        // ---- Admin Routes ----
        if (path.startsWith('admin/')) {
            const adminPath = path.replace('admin/', '');

            // POST /api/admin/login
            if (adminPath === 'login' && request.method === 'POST') {
                const body = await request.json();
                const settings = await getSettings(context);
                
                if (body.username === settings.adminUsername && 
                    body.password === (settings.adminPassword || 'admin123')) {
                    const token = btoa(settings.adminUsername + ':' + (settings.adminPassword || 'admin123'));
                    return jsonResponse({ token, username: settings.adminUsername });
                }
                return errorResponse('用户名或密码错误', 401);
            }

            // Verify admin for all other admin routes
            if (adminPath !== 'login') {
                const isAdmin = await verifyAdmin(context);
                if (!isAdmin) {
                    return errorResponse('未授权', 401);
                }
            }

            // GET/POST /api/admin/settings
            if (adminPath === 'settings') {
                if (request.method === 'GET') {
                    const settings = await getSettings(context);
                    return jsonResponse({
                        siteTitle: settings.siteTitle,
                        siteLogo: settings.siteLogo,
                        siteIcon: settings.siteIcon,
                        uploadPassword: settings.uploadPassword,
                        adminUsername: settings.adminUsername,
                        defaultBackend: settings.defaultBackend
                    });
                }
                if (request.method === 'POST') {
                    const body = await request.json();
                    const updateData = { ...body };
                    if (body.adminPassword) {
                        updateData.adminPassword = body.adminPassword;
                    }
                    await saveSettings(context, updateData);
                    return jsonResponse({ success: true });
                }
            }

            // GET/POST/PUT/DELETE /api/admin/backends
            if (adminPath === 'backends') {
                if (request.method === 'GET') {
                    const backends = await getBackends(context);
                    return jsonResponse({ backends });
                }
                if (request.method === 'POST') {
                    const body = await request.json();
                    const backends = await getBackends(context);
                    const newBackend = {
                        id: 'be_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
                        name: body.name,
                        type: 'telegram',
                        botToken: body.botToken,
                        chatId: body.chatId,
                        proxyUrl: body.proxyUrl || '',
                        enabled: body.enabled !== false
                    };
                    backends.push(newBackend);
                    await saveBackends(context, backends);
                    return jsonResponse({ success: true, backend: newBackend });
                }
                if (request.method === 'PUT') {
                    const body = await request.json();
                    const backends = await getBackends(context);
                    const idx = backends.findIndex(b => b.id === body.id);
                    if (idx === -1) return errorResponse('后端不存在', 404);
                    backends[idx] = { ...backends[idx], ...body };
                    delete backends[idx].id;
                    backends[idx].id = body.id;
                    await saveBackends(context, backends);
                    return jsonResponse({ success: true });
                }
                if (request.method === 'DELETE') {
                    const body = await request.json();
                    const backends = await getBackends(context);
                    const filtered = backends.filter(b => b.id !== body.id);
                    await saveBackends(context, filtered);
                    return jsonResponse({ success: true });
                }
            }

            // GET /api/admin/files
            if (adminPath === 'files' && request.method === 'GET') {
                const limit = parseInt(url.searchParams.get('limit') || '24');
                const result = await listFileMetadata(context, { limit });
                result.files = result.files.map(f => ({
                    ...f,
                    url: `/api/file/${f.id}`
                }));
                return jsonResponse(result);
            }

            // POST /api/admin/delete
            if (adminPath === 'delete' && request.method === 'POST') {
                const body = await request.json();
                const fileId = body.id;
                const meta = await getFileMetadata(context, fileId);
                if (!meta) return errorResponse('文件不存在', 404);

                // Try to delete from Telegram
                const backends = await getBackends(context);
                const backend = backends.find(b => b.id === meta.backendId);
                if (backend && meta.telegramMessageId) {
                    try {
                        await deleteTelegramMessage(backend, backend.chatId, meta.telegramMessageId);
                    } catch(e) {
                        // Continue even if Telegram delete fails
                    }
                }

                await deleteFileMetadata(context, fileId);
                return jsonResponse({ success: true });
            }
        }

        return errorResponse('Not found', 404);

    } catch (err) {
        console.error('API Error:', err);
        return errorResponse(err.message || 'Internal server error', 500);
    }
}

// ============================================================
// Upload Handler
// ============================================================
async function handleUpload(context) {
    const { request } = context;
    const formData = await request.formData();
    const file = formData.get('file');
    const password = formData.get('password');
    const backendId = formData.get('backendId');

    if (!file) {
        return errorResponse('未找到文件', 400);
    }

    // Verify upload password
    const settings = await getSettings(context);
    if (settings.uploadPassword) {
        if (password !== settings.uploadPassword) {
            return errorResponse('上传密码错误', 403);
        }
    }

    // Check file size (20MB limit for Telegram)
    const MAX_SIZE = 20 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
        return errorResponse('文件超过20MB限制', 413);
    }

    // Get backends
    const backends = await getBackends(context);
    const enabledBackends = backends.filter(b => b.enabled);

    if (enabledBackends.length === 0) {
        return errorResponse('没有可用的存储后端，请在后台添加 Telegram Bot', 503);
    }

    // Select backend
    let selectedBackend;
    if (backendId) {
        selectedBackend = enabledBackends.find(b => b.id === backendId);
        if (!selectedBackend) {
            return errorResponse('指定的存储后端不可用', 400);
        }
    } else if (settings.defaultBackend) {
        selectedBackend = enabledBackends.find(b => b.id === settings.defaultBackend);
    }
    
    // Fallback to first enabled, try each if upload fails
    if (!selectedBackend) {
        selectedBackend = enabledBackends[0];
    }

    // Try uploading, with fallback to other backends
    let uploadResult = null;
    let lastError = null;
    const triedBackends = new Set();
    
    // Try selected backend first
    const candidates = [selectedBackend, ...enabledBackends.filter(b => b.id !== selectedBackend.id)];
    
    for (const backend of candidates) {
        if (triedBackends.has(backend.id)) continue;
        triedBackends.add(backend.id);
        
        try {
            uploadResult = await sendFileToTelegram(file, backend);
            selectedBackend = backend;
            break;
        } catch (err) {
            lastError = err;
            console.log(`Upload to backend ${backend.name} failed:`, err.message);
        }
    }

    if (!uploadResult) {
        return errorResponse('所有存储后端上传失败: ' + (lastError?.message || 'Unknown error'), 502);
    }

    // Generate file ID and save metadata
    const fileId = generateFileId();
    const fileMeta = {
        id: fileId,
        name: file.name || uploadResult.fileName,
        size: file.size || uploadResult.fileSize,
        type: file.type || uploadResult.mimeType,
        uploadTime: new Date().toISOString(),
        backendId: selectedBackend.id,
        backendName: selectedBackend.name,
        telegramMessageId: uploadResult.messageId,
        telegramFileId: uploadResult.fileId,
        telegramFileUniqueId: uploadResult.fileUniqueId
    };

    await saveFileMetadata(context, fileMeta);

    return jsonResponse({
        success: true,
        id: fileId,
        name: fileMeta.name,
        size: fileMeta.size,
        type: fileMeta.type,
        url: `/api/file/${fileId}`,
        uploadTime: fileMeta.uploadTime
    });
}

// ============================================================
// File Serving Handler
// ============================================================
async function handleServeFile(context, fileId) {
    const meta = await getFileMetadata(context, fileId);
    if (!meta) {
        return new Response('File not found', { status: 404 });
    }

    // Get the backend that stored this file
    const backends = await getBackends(context);
    const backend = backends.find(b => b.id === meta.backendId);
    if (!backend) {
        return new Response('Storage backend not found', { status: 503 });
    }

    // Get file URL from Telegram
    try {
        const fileUrl = await getTelegramFileUrl(backend, meta.telegramFileId);
        
        // Fetch the file from Telegram
        const response = await fetch(fileUrl);
        if (!response.ok) {
            return new Response('Failed to fetch file', { status: 502 });
        }

        // Stream the response with appropriate headers
        const headers = new Headers(response.headers);
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Cache-Control', 'public, max-age=86400');
        
        // Set content type
        if (meta.type) {
            headers.set('Content-Type', meta.type);
        }
        
        // Set content disposition (inline for images/videos, attachment for others)
        const fileType = getFileCategory(meta.type, meta.name);
        const disposition = fileType === 'image' || fileType === 'video' ? 'inline' : 'attachment';
        headers.set('Content-Disposition', `${disposition}; filename="${encodeURIComponent(meta.name)}"`);

        return new Response(response.body, {
            status: response.status,
            headers
        });
    } catch (err) {
        console.error('File serving error:', err);
        return new Response('Failed to retrieve file: ' + err.message, { status: 502 });
    }
}
